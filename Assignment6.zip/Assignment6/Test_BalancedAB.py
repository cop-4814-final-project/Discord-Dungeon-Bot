import unittest
import BalancedAB

class TestBalancedAB(unittest.TestCase):
    def test_BalancedAB1(self):
        self.assertTrue(BalancedAB.BalancedAB("AAZZBB"))

    def test_BalancedAB2(self):
        self.assertTrue(BalancedAB.BalancedAB("AAAXXXXYB"))

    def test_BalancedAB3(self):
        self.assertFalse(BalancedAB.BalancedAB("BBYYYXXXAXX"))

    def test_BalancedAB4(self):
        self.assertTrue(BalancedAB.BalancedAB(""))

    def test_BalancedAB5(self):
        self.assertTrue(BalancedAB.BalancedAB("XXXXXYYYYZZZZB"))

    def test_BalancedAB6(self):
        self.assertTrue(BalancedAB.BalancedAB(" XXXXXYYYYZZZZ"))

    def test_BalancedAB7(self):
        self.assertTrue(BalancedAB.BalancedAB("XXXX XYYYY ZZZZB"))

    def test_BalancedAB8(self):
        self.assertFalse(BalancedAB.BalancedAB("YYYBABYYYXXXAXX"))

    def test_BalancedAB9(self):
        self.assertFalse(BalancedAB.BalancedAB("ABABABA"))

    def test_BalancedAB10(self):
        self.assertFalse(BalancedAB.BalancedAB("A"))

if __name__ == '__main__':
    unittest.main()
