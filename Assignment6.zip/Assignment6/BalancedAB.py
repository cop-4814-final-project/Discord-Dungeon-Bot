def BalancedAB(st):
    try:
        st.rindex("A")
        try:
            st.rindex("B", st.rindex("A"))
            return True
        except ValueError:
            return False
    except ValueError:
        return True